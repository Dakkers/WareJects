$(document).ready(function () {
	$('#projects').click(function(){
		window.open('index.html', "_blank");
	});

	$("#about").click(function () {
		window.open('http://www.stdako.com/projects.html', '_blank');
	});
});