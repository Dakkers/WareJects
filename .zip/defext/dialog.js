f = new Folder("/usr/bin");
f = folder.selectDlg("wot");
alert (f);