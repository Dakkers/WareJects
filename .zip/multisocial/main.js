function pushfb (text) {

	var status = encodeURIComponent(text);
	var strUrl = "phclub.uwaterloo.ca?param="+status;
	var strReturn = "";

	jQuery.ajax({
		url: strUrl,
		success: function(html) {
			strReturn = html;
		},
		async:false
	});
}



$(document).ready(function () {

	$('#pushtext').click(function() {
		var txt = $('#texttopush').val();		//get text from the textarea box

		$('.check').each(function(i) {			//go through each checkbox

			if ($(this).is(':checked')) {		//see if checkbox is checked
				
				if ($(this).attr('value') === 'facebook') {		//if the checkbox is for FB...
					pushfb(txt);								//push a status update
				};
			};
		});
	});
});