import facebook
from flask import Flask, request
app = Flask(__name__)

@app.route("/")
def request_handler(methods=['POST', 'GET']):
	global __name__
	token = 'CAAUIlfsLeV4BAA22Vh4abR6J1PyKDNVWxpIx15DFFtzAGU2hl8n2hZC7lebk5FugJAV0vOdOPWnBP1g6U7iPKdKOKZCF5ZB6QxtKkfZBYGtj8xAZBJOaz1MeqAZCHNj63TSS0E2gon2flX6gSyjZCc7DQWbjS2WILB48ZCKqtIz47VxppEAtXETZCdKaIS2vfb27Xil63zssgZCAZDZD'
	try:
		graph = facebook.GraphAPI(token)
	except:
		return 'need new token'

	if request.method == 'GET':
		if 'param' in request.args:
			txt = request.args['param']
			if txt is not None:
				graph.put_wall_post(txt)
				return 'posted' + txt

	return 'everything seems good'

if __name__ == "__main__":
	app.run(host='phclub.uwaterloo.ca')